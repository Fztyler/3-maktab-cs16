﻿param([string]$GamePath)
$ErrorActionPreference='Stop'
try {
 if(!$GamePath){Add-Type -AssemblyName System.Windows.Forms;$dialog=New-Object System.Windows.Forms.FolderBrowserDialog;$dialog.Description='Select Counter-Strike 1.6 folder (contains hl.exe)';if($dialog.ShowDialog() -ne 'OK'){exit};$GamePath=$dialog.SelectedPath}
 $GamePath=(Resolve-Path -LiteralPath $GamePath).Path
 if(!(Test-Path -LiteralPath (Join-Path $GamePath 'hl.exe')) -or !(Test-Path -LiteralPath (Join-Path $GamePath 'cstrike'))){throw 'Select the CS 1.6 folder containing hl.exe and cstrike.'}
 if(Get-Process hl -ErrorAction SilentlyContinue | Where-Object {$_.Path -eq (Join-Path $GamePath 'hl.exe')}){throw 'Close Counter-Strike before installing.'}
 $source=Join-Path $PSScriptRoot 'payload';$backup=Join-Path $GamePath ('maktab-backup-'+(Get-Date -Format yyyyMMdd-HHmmss-fff))
 foreach($file in Get-ChildItem -LiteralPath $source -File -Recurse){$relative=$file.FullName.Substring($source.Length+1);$dest=Join-Path $GamePath $relative;if(Test-Path -LiteralPath $dest){$saved=Join-Path $backup $relative;New-Item -ItemType Directory -Path (Split-Path $saved) -Force | Out-Null;Copy-Item -LiteralPath $dest -Destination $saved};New-Item -ItemType Directory -Path (Split-Path $dest) -Force | Out-Null;Copy-Item -LiteralPath $file.FullName -Destination $dest -Force}
 $launch='@echo off'+"`r`n"+'cd /d "%~dp0"'+"`r`n"+'start "" "hl.exe" -game cstrike -console +maxplayers 20 +map de_3_maktab'+"`r`n"
 Set-Content -LiteralPath (Join-Path $GamePath 'PLAY_3_MAKTAB.cmd') -Value $launch -Encoding Ascii
 Write-Host 'Installed! Run PLAY_3_MAKTAB.cmd in your game folder. Pick a team; bots fill 5 vs 5.' -ForegroundColor Green
 Write-Host ('Previous files backed up in: '+$backup)
} catch {Write-Host $_.Exception.Message -ForegroundColor Red;exit 1}
