3 MAKTAB - FINAL - Windows CS 1.6

1. Extract this entire ZIP.
2. Close CS and double-click INSTALL.cmd. Select your CS folder (hl.exe).
3. Run PLAY_3_MAKTAB.cmd from that folder. Select T or CT. Bots fill 5 vs 5.

Includes map, textures, models, music, bot navigation and required server support. No Blender, Python or editor needed. Existing replaced files are backed up. This installer also installs server components; use a separate game copy for an already modified server. Friends joining your server only need the map/resources.

RU: Распакуй ZIP, закрой CS, запусти INSTALL.cmd, выбери папку с hl.exe. Затем PLAY_3_MAKTAB.cmd в папке игры.
